C++ Functions for Task 1:
Author: Pratik Nimbalkar(2020CS10607) 

All functions are present in 2020CS10607.cpp file.

Following are the functions - 
1. matrix_multiply - It takes two flat matrices and their dimensions as their input and calculates their product and saves it in result_arr.

2. matrix_add - It takes 2 matrices and their dimension and adds them.

3. task_1 - It performs fullyconnected task. takes two matrices from text files and prints their product in another text file.

4. tanh_ - it takes a float as input and returns its tanh value.

5. relu - it takes a float as input and returns its relu value.

6. task_2a - it takes input matrix from a text file and prints a matrix with all tanh values of respective elements in another text file.

7. task_2b - it takes input matrix from a text file and prints a matrix with all relu values of respective elements in another text file.

8. pooling - it takes a matrix, pooling size and type of pooling and performs pooling operation according to the given conditions, and saves it in result_arr.

9. task_3 - it takes a matrix and pooling size, type as input and prints the matrix left after pooling in another text file.

10. sigmoid - it takes a float value and returns its sigmoid value.

11. task_4a - it takes a vector from a text file and then applies sigmoid on all elements and then saves it in another txt file.

12. task_4b - it takes a vector from a text file and then calculates softmax of every element and then saves the values in another text file.

